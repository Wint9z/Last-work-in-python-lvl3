from database import (
    add_user,
    create_profile,
    add_score,
    get_profile,
    set_question,
    get_question,
    reset_scores
)

from keyboards import main_menu



# ВОПРОСЫ


questions = [

    
    {
        "question": "🧠 Тебе нравится решать сложные задачи?",
        "category": "logic"
    },

    {
        "question": "🧠 Любишь математику?",
        "category": "logic"
    },

    {
        "question": "🧠 Интересны головоломки?",
        "category": "logic"
    },

    {
        "question": "🧠 Любишь искать ошибки и исправлять их?",
        "category": "logic"
    },


  
    {
        "question": "🎨 Любишь рисовать?",
        "category": "creative"
    },

    {
        "question": "🎨 Нравится придумывать идеи?",
        "category": "creative"
    },

    {
        "question": "🎨 Интересен дизайн?",
        "category": "creative"
    },

    {
        "question": "🎨 Хотел бы создавать что-то новое?",
        "category": "creative"
    },



    {
        "question": "👥 Любишь общаться?",
        "category": "social"
    },

    {
        "question": "👥 Легко заводишь друзей?",
        "category": "social"
    },

    {
        "question": "👥 Нравится помогать людям?",
        "category": "social"
    },

    {
        "question": "👥 Комфортно выступать перед людьми?",
        "category": "social"
    },


    
    {
        "question": "👑 Часто берёшь инициативу?",
        "category": "leadership"
    },

    {
        "question": "👑 Любишь организовывать людей?",
        "category": "leadership"
    },

    {
        "question": "👑 Хочешь управлять проектами?",
        "category": "leadership"
    },


  
    {
        "question": "💻 Интересны компьютеры?",
        "category": "tech"
    },

    {
        "question": "💻 Любишь разбираться в технике?",
        "category": "tech"
    },

    {
        "question": "💻 Хотел бы создавать приложения?",
        "category": "tech"
    },


   
    {
        "question": "📚 Можешь долго работать над одной задачей?",
        "category": "discipline"
    },

    {
        "question": "📚 Доводишь дела до конца?",
        "category": "discipline"
    },

    {
        "question": "📚 Способен учиться часами?",
        "category": "discipline"
    }
]



# ПОКАЗ ВОПР


def show_question(update, user_id):

    question_index = get_question(user_id)

    if question_index >= len(questions):

        update.message.reply_text(
            "🏁 Тест завершён!\nНапиши: Результат"
        )

        return

    question = questions[question_index]["question"]

    update.message.reply_text(
        f"""
❓ Вопрос {question_index + 1}/{len(questions)}

{question}

Ответь:
Да / Нет
"""
    )



# START


def start(update, context):

    user = update.message.from_user

    add_user(user.id, user.username)

    create_profile(user.id)

    update.message.reply_text(
        "👋 Привет! Я помогу выбрать профессию 🚀",
        reply_markup=main_menu()
    )



# СТАРТ 


def test(update, context):

    user_id = update.message.from_user.id

    reset_scores(user_id)

    show_question(update, user_id)



# ОБРАБОТКА 


def handle_text(update, context):

    text = update.message.text.lower()

    user_id = update.message.from_user.id


    # СТАРТ ТЕСТА
    if "начать" in text:

        test(update, context)
        return


    # РЕЗУЛЬТАТ
    if text == "результат":

        profile = get_profile(user_id)

        if profile is None:

            update.message.reply_text(
                "Сначала пройди тест 🙂"
            )

            return


        logic, creative, social, leadership, tech, discipline = profile


        profession = get_profession(
            logic,
            creative,
            social,
            leadership,
            tech,
            discipline
        )


        update.message.reply_text(
            f"""
📊 ТВОЙ ПРОФИЛЬ

🧠 Логика: {logic}
🎨 Творчество: {creative}
👥 Общение: {social}
👑 Лидерство: {leadership}
💻 Технологии: {tech}
📚 Дисциплина: {discipline}

🏆 ТЕБЕ ПОДХОДИТ:

{profession}
"""
        )

        return


  
    question_index = get_question(user_id)

    if question_index >= len(questions):
        return


    current_question = questions[question_index]


    
    if text == "да":

        add_score(
            user_id,
            current_question["category"],
            1
        )


    set_question(
        user_id,
        question_index + 1
    )


    show_question(update, user_id)



# ЛОГИКА ПРОФЕССИЙ


def get_profession(
    logic,
    creative,
    social,
    leadership,
    tech,
    discipline
):

  
    if logic >= 3 and tech >= 2:
        return """
👨‍💻 Программист

Ты любишь логику, технологии и решение задач.
Программисты создают сайты, приложения, игры и ИИ.

📌 Тебе могут подойти:
• Python разработка
• Создание игр
• Веб-разработка
• Data Science
• Искусственный интеллект
"""


  
    elif creative >= 3 and tech >= 2:
        return """
🎨 UX/UI Дизайнер

Ты творческий человек с интересом к технологиям.
UX/UI дизайнеры делают удобные и красивые приложения и сайты.

📌 Тебе могут подойти:
• Дизайн интерфейсов
• Графический дизайн
• Figma / Photoshop
• Motion Design
"""


  
    elif social >= 3:
        return """
👥 Психолог

Ты хорошо понимаешь людей и любишь общение.
Психологи помогают людям решать проблемы и понимать себя.

📌 Тебе могут подойти:
• Психология
• Коучинг
• HR
• Работа с людьми
"""



  
    elif leadership >= 3 and social >= 2:
        return """
🚀 Предприниматель

У тебя есть лидерские качества и желание создавать что-то своё.
Предприниматели запускают проекты, управляют командами и развивают бизнес.

📌 Тебе могут подойти:
• Стартапы
• Бизнес
• Управление командами
• Продажи
"""


   
    elif logic >= 3 and tech >= 3:
        return """
⚙️ Инженер

Ты любишь технологии, аналитику и точность.
Инженеры создают механизмы, системы и технические решения.

📌 Тебе могут подойти:
• Робототехника
• Механика
• IT-инженерия
• Архитектура систем
"""


    elif leadership >= 2 and discipline >= 2:
        return """
📈 Менеджер проектов

Ты умеешь организовывать людей и доводить дела до конца.
Менеджеры проектов управляют командами и следят за выполнением задач.

📌 Тебе могут подойти:
• Project Management
• Управление командами
• Бизнес-процессы
• Организация проектов
"""



    
    elif creative >= 2 and social >= 2:
        return """
📢 Маркетолог

Ты креативный и общительный человек.
Маркетологи продвигают продукты, создают рекламу и изучают аудиторию.

📌 Тебе могут подойти:
• SMM
• Реклама
• Контент
• Брендинг
"""


    
    elif logic >= 4:
        return """
📊 Аналитик

Ты любишь анализировать информацию и искать закономерности.
Аналитики помогают компаниям принимать решения на основе данных.

📌 Тебе могут подойти:
• Data Analytics
• Финансовая аналитика
• BI
• Исследования данных
"""


   
    else:
        return """
🧩 Универсальный тип

У тебя сразу несколько сильных сторон.
Ты можешь пробовать себя в разных направлениях и совмещать навыки.

📌 Тебе стоит изучить:
• Разные профессии
• Командные проекты
• Творческие и технические сферы
"""