import matplotlib.pyplot as plt
import sqlite3


def get_data(start_date, end_date):
    con = sqlite3.connect('data.db')
    cur = con.cursor()
    cur.execute("SELECT * FROM data WHERE date BETWEEN ? AND ? ORDER BY date ", (start_date, end_date))
    res = cur.fetchall()
    con.close()
    dates = [res[i][0] for i in range(len(res))]
    prices = [res[i][1] for i in range(len(res))]
    return dates, prices


def plot_usd_graph(dates, prices):
    filename = 'usd_graph.png'

    plt.figure(figsize=(10, 6))
    plt.plot(dates, prices)

    plt.title('Курс доллара по датам')
    plt.xlabel('Дата')
    plt.ylabel('Цена')

    
    step = 100
    plt.xticks(dates[::step], rotation=45)

    plt.grid(True)
    plt.tight_layout()

    plt.savefig(filename)
    plt.close()

    return filename

dates, prices = get_data('2001-01-01', '2023-01-01')
print(plot_usd_graph(dates, prices))
