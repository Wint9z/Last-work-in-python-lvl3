import matplotlib.pyplot as plt

def plot_day_night_temp(day_temps, night_temps):
    days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
    filename = 'day_night_temperature.png'
    
    plt.figure(figsize=(8, 6))
    plt.plot(days, day_temps, color='red', marker='o', label='День')
    plt.plot(days, night_temps, color='blue', marker='o', label='Ночь')

    plt.title('Дневная и ночная температура за неделю')
    plt.xlabel('Дни недели')
    plt.ylabel('Температура (°C)')
    plt.grid(True)
    plt.legend()

    plt.savefig(filename)
    plt.show()  

    return filename
   

day = [20, 22, 19, 23, 25, 24, 21]
night = [12, 14, 13, 15, 16, 15, 13]

print(plot_day_night_temp(day, night))
