import cv2
import matplotlib.pyplot as plt

img = cv2.imread('image.png')
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

h, w, _ = img.shape


plt.figure(figsize=(6,6))


plt.show()