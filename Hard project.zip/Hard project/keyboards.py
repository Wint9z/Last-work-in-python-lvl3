from telegram import ReplyKeyboardMarkup


def main_menu():

    keyboard = [
        ["Начать тест"],
        ["Результат"]
    ]

    return ReplyKeyboardMarkup(
        keyboard,
        resize_keyboard=True
    )




def test_keyboard():

    keyboard = [
        ["Решать задачи"],
        ["Рисовать"],
        ["Общаться"],
        ["Результат"]  
    ]

    return ReplyKeyboardMarkup(
        keyboard,
        resize_keyboard=True
    )