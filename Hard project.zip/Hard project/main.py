from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
from config import TOKEN
from bot import start, handle_text
from database import create_users_table, create_user_profile_table

def main():

    create_users_table()
    create_user_profile_table()


    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    
    dp.add_handler(CommandHandler("start", start))


    
    dp.add_handler(MessageHandler(Filters.text, handle_text))

    print("Бот запущен...")

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()

