import sqlite3

conn = sqlite3.connect("database.db", check_same_thread=False)
cursor = conn.cursor()



# СОЗДАНИЕ ТАБ


def create_users_table():

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        username TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()


def create_user_profile_table():

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_profile (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER UNIQUE,

        logic_score INTEGER DEFAULT 0,
        creative_score INTEGER DEFAULT 0,
        social_score INTEGER DEFAULT 0,

        leadership_score INTEGER DEFAULT 0,
        tech_score INTEGER DEFAULT 0,
        discipline_score INTEGER DEFAULT 0,

        current_question INTEGER DEFAULT 0
    )
    """)

    conn.commit()



# ЮЗЕРЫ


def add_user(user_id, username):

    cursor.execute("""
    INSERT OR IGNORE INTO users (user_id, username)
    VALUES (?, ?)
    """, (user_id, username))

    conn.commit()


def create_profile(user_id):

    cursor.execute("""
    INSERT OR IGNORE INTO user_profile (user_id)
    VALUES (?)
    """, (user_id,))

    conn.commit()



# ОЧКИ


def add_score(user_id, category, points):

    fields = {
        "logic": "logic_score",
        "creative": "creative_score",
        "social": "social_score",
        "leadership": "leadership_score",
        "tech": "tech_score",
        "discipline": "discipline_score"
    }

    field = fields.get(category)

    if not field:
        return

    cursor.execute(f"""
    UPDATE user_profile
    SET {field} = {field} + ?
    WHERE user_id = ?
    """, (points, user_id))

    conn.commit()



# ПРОФИЛЬ


def get_profile(user_id):

    cursor.execute("""
    SELECT
        logic_score,
        creative_score,
        social_score,
        leadership_score,
        tech_score,
        discipline_score
    FROM user_profile
    WHERE user_id = ?
    """, (user_id,))

    return cursor.fetchone()



# ВОПРОСЫ


def set_question(user_id, question_number):

    cursor.execute("""
    UPDATE user_profile
    SET current_question = ?
    WHERE user_id = ?
    """, (question_number, user_id))

    conn.commit()


def get_question(user_id):

    cursor.execute("""
    SELECT current_question
    FROM user_profile
    WHERE user_id = ?
    """, (user_id,))

    result = cursor.fetchone()

    if result:
        return result[0]

    return 0



# СБРОС ТЕСТА


def reset_scores(user_id):

    cursor.execute("""
    UPDATE user_profile
    SET
        logic_score = 0,
        creative_score = 0,
        social_score = 0,
        leadership_score = 0,
        tech_score = 0,
        discipline_score = 0,
        current_question = 0
    WHERE user_id = ?
    """, (user_id,))

    conn.commit()